import json
import csv

dir = "C:/Users/jasper villarosa/downloads/testing.json"
f = open(dir, 'r')

data = json.load(f)

header = []
category_id = []
header.append("Filename")
for i in range(len(data['categories'])):
    header.append(data['categories'][i]['name'])
    category_id.append(data['categories'][i]['id'])

print (header)
print("categories= ", category_id)

savefile = "C:/Users/jasper villarosa/downloads/testing.csv"

file = open(savefile, "w", newline='')
write = csv.writer(file)

write.writerow(header)

image_id = []
objects = []

for i in range (len(data['images'])):
    image_id.append(data['images'][i]['id'])

print("images= ", len(image_id))

for i in range(len(image_id)):
    for z in range(len(category_id)):
        objects.append(0)

    for j in range(len(data['annotations'])):
        for k in range(len(data['categories'])):
            if data['annotations'][j]['category_id'] == category_id[k] and data['annotations'][j]['image_id']==image_id[i]:
                objects[category_id[k]-1] +=1

    image_name = [data['images'][k]['file_name']]

    for z in range (len(objects)):
        image_name.append(objects[z])

    write.writerow(image_name)
    objects.clear()
    #print (objects)
